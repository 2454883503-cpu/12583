import { Session } from 'koishi';
import { ChatInvocationInput, ChatInvocationResult, ConversationRecord, ConversationResolution, Message } from '../types';
import type { ChatOptions } from './conversation_runtime';
import type { ChatLunaService } from './chat';
export declare class ChatInvocationRuntime {
    private readonly service;
    constructor(service: ChatLunaService);
    invoke(input: ChatInvocationInput): Promise<ChatInvocationResult>;
    request(session: Session, options: RequestOptions): Promise<{
        resolution: ActiveResolution;
        conversation: ConversationRecord;
        response: Message;
    }>;
    chat(session: Session, conversation: ConversationRecord, message: Message, options?: ChatOptions): Promise<Message>;
    private resolveSession;
    private resolveConversation;
    private cleanupEphemeral;
}
type ActiveResolution = ConversationResolution & {
    conversation: ConversationRecord;
};
interface RequestOptions {
    conversation?: ConversationResolution;
    prepare: (args: {
        conversation: ConversationRecord;
        resolution: ActiveResolution;
    }) => Promise<{
        message: Message;
        chat: ChatOptions;
    }>;
    onResponse?: (args: {
        response: Message;
        conversation: ConversationRecord;
        resolution: ActiveResolution;
    }) => Promise<void>;
}
export {};
