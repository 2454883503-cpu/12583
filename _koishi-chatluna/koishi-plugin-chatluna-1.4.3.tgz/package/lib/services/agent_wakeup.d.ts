import { Context } from 'koishi';
import type { Config } from '../config';
export declare function applyAgentTaskWakeup(ctx: Context, config: Config): void;
