import type { Context, Session } from 'koishi';
import type { PlatformService } from 'koishi-plugin-chatluna/llm-core/platform/service';
import type { Config } from '../config';
import { ACLRecord, ActiveConversationResolution, ArchiveRecord, BindingRecord, ConstraintRecord, ConversationListEntry, ConversationRecord, ConversationResolution, MessageRecord, ResolveConversationOptions, ResolvedConstraint, ResolveInvocationInput } from '../types';
import { ListConversationsOptions } from './types';
import type { ConversationRuntime } from './conversation_runtime';
import type { PresetService } from 'koishi-plugin-chatluna/preset';
export declare class ConversationService {
    private readonly ctx;
    private readonly config;
    private readonly runtime;
    private readonly platform;
    private readonly preset;
    private readonly _bindingLocks;
    private readonly _titleLocks;
    constructor(ctx: Context, config: Config, runtime: ConversationRuntime, platform: PlatformService, preset: PresetService);
    getConversation(id: string): Promise<ConversationRecord>;
    getBinding(bindingKey: string): Promise<BindingRecord>;
    getArchive(id: string): Promise<ArchiveRecord>;
    getArchiveByConversationId(conversationId: string): Promise<ArchiveRecord>;
    listConstraints(): Promise<ConstraintRecord[]>;
    resolveConstraint(session: Session, options?: ResolveConversationOptions): Promise<ResolvedConstraint>;
    private normalizeBindingKey;
    private resolveConversationContext;
    resolveConversation(session: Session, options?: ResolveConversationOptions): Promise<ConversationResolution>;
    private resolveActiveMode;
    private resolveTargetMode;
    private buildContext;
    private resolveBindingForKey;
    ensureActiveConversation(session: Session, options?: ResolveConversationOptions): Promise<ActiveConversationResolution>;
    prepareInvocation(session: Session, input: ResolveInvocationInput): Promise<ActiveConversationResolution>;
    private createEphemeral;
    private createInvocationConversation;
    private requireActiveTarget;
    private applyInvocationOverlay;
    private requireInvocationPreset;
    createConversation(session: Session, options: {
        bindingKey: string;
        title: string;
        model: string;
        preset: string;
        chatMode: string;
        setActive?: boolean;
        /**
         * When set, re-check for an existing active conversation with this
         * bindingKey inside the lock and return it instead of creating.
         */
        reuseBindingKey?: string;
    }): Promise<ConversationRecord>;
    setActiveConversation(bindingKey: string, conversationId: string): Promise<BindingRecord>;
    touchConversation(conversationId: string, patch?: Partial<ConversationRecord>): Promise<ConversationRecord>;
    claimAutoTitle(conversationId: string): Promise<boolean>;
    listConversations(session: Session, options?: ListConversationsOptions): Promise<ConversationRecord[]>;
    listConversationEntries(session: Session, options?: ListConversationsOptions): Promise<ConversationListEntry[]>;
    private getTarget;
    switchConversation(session: Session, options: ResolveConversationOptions): Promise<ConversationRecord>;
    reopenConversation(session: Session, options: ResolveConversationOptions): Promise<ConversationRecord>;
    listMessages(conversationId: string): Promise<MessageRecord[]>;
    listAcl(conversationId: string): Promise<ACLRecord[]>;
    upsertAcl(conversationId: string, records: Omit<ACLRecord, 'conversationId'>[]): Promise<ACLRecord[]>;
    replaceAcl(conversationId: string, records: Omit<ACLRecord, 'conversationId'>[]): Promise<ACLRecord[]>;
    removeAcl(conversationId: string, records?: Partial<Omit<ACLRecord, 'conversationId'>>[]): Promise<ACLRecord[]>;
    exportConversation(session: Session, options?: ResolveConversationOptions & {
        outputPath?: string;
    }): Promise<{
        conversation: ConversationRecord;
        path: string;
        size: number;
    }>;
    archiveConversation(session: Session, options?: ResolveConversationOptions): Promise<{
        conversation: ConversationRecord;
        archive: ArchiveRecord;
        path: string;
    }>;
    archiveConversationById(conversationId: string, inactiveBefore?: Date): Promise<{
        conversation: ConversationRecord;
        archive: ArchiveRecord;
        path: string;
    }>;
    restoreConversation(session: Session, options?: ResolveConversationOptions & {
        archiveId?: string;
    }): Promise<ConversationRecord>;
    exportMarkdown(conversation: ConversationRecord): Promise<string>;
    private loadMessagesForExport;
    renameConversation(session: Session, options: ResolveConversationOptions & {
        title: string;
    }): Promise<ConversationRecord>;
    deleteConversation(session: Session, options?: ResolveConversationOptions): Promise<ConversationRecord>;
    updateConversationUsage(session: Session, options: ResolveConversationOptions & {
        model?: string;
        auto?: boolean;
        preset?: string;
        chatMode?: string;
    }): Promise<ConversationRecord>;
    applyAutoModelUpdate(resolved: ConversationResolution, command?: string): Promise<ConversationRecord>;
    recordCompression(conversationId: string, result: {
        compressed: boolean;
        inputTokens: number;
        outputTokens: number;
        reducedTokens: number;
        reducedPercent: number;
        originalMessageCount: number;
        remainingMessageCount: number;
    }): Promise<ConversationRecord>;
    getManagedConstraint(session: Session): Promise<ConstraintRecord>;
    getManagedConstraintByBindingKey(bindingKey: string): Promise<ConstraintRecord>;
    updateManagedConstraint(session: Session, patch: Partial<ConstraintRecord>): Promise<ConstraintRecord>;
    updateManagedConstraintByBindingKey(session: Session, bindingKey: string, patch: Partial<ConstraintRecord>): Promise<ConstraintRecord>;
    private updateManagedConstraintFor;
    pickModel(constraint: ResolvedConstraint, conversation?: ConversationRecord | null): string;
    private firstRow;
    private getDefaultRouteMode;
    private checkChatMode;
    private allocateConversationSeq;
    private findAccessibleConversations;
    private collectAclConversationIds;
    private ensureDataDir;
}
