import { h, Session } from 'koishi';
import { Config } from 'koishi-plugin-chatluna';
import { Message } from '../types';
export declare class MessageTransformer {
    private _config;
    private _beforeTransformFunctions;
    private _transformFunctions;
    constructor(_config: Config);
    transform(session: Session, elements: h[], model: string, message?: Message, options?: MessageTransformOptions): Promise<Message>;
    before(transformFunction: BeforeMessageTransformFunction, priority?: number): () => void;
    intercept(type: string, transformFunction: MessageTransformFunction, priority?: number): () => void;
    replace(type: string, transformFunction: MessageTransformFunction): () => void;
    has(type: string): boolean;
    private _processElement;
    private _runBeforeTransform;
}
export type BeforeMessageTransformFunction = (session: Session, elements: h[], message: Message, model?: string, options?: MessageTransformOptions) => Promise<void>;
export type MessageTransformFunction = (session: Session, element: h, message: Message, model?: string) => Promise<boolean | void>;
export interface MessageTransformOptions {
    quote: boolean;
    includeQuoteReply: boolean;
}
