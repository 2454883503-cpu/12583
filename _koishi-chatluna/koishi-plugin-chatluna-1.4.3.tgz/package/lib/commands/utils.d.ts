import { Context, Session } from 'koishi';
export declare function completeConversationTarget(ctx: Context, session: Session, target: string | undefined, presetLane?: string, includeArchived?: boolean, suffix?: string): Promise<string>;
