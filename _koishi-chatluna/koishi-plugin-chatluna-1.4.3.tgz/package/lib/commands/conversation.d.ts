import { Context } from 'koishi';
import { Config } from '../config';
import { ChatChain } from '../chains/chain';
export declare function apply(ctx: Context, _config: Config, chain: ChatChain): void;
declare module '../chains/chain' {
    interface ChainMiddlewareContextOptions {
        conversation_create?: {
            title?: string;
            preset?: string;
            model?: string;
            chatMode?: string;
        };
        conversation_manage?: {
            targetConversation?: string;
            presetLane?: string;
            includeArchived?: boolean;
            title?: string;
        };
        conversation_use?: {
            model?: string;
            auto?: boolean;
            preset?: string;
            chatMode?: string;
        };
        conversation_rule?: {
            model?: string;
            preset?: string;
            chatMode?: string;
            share?: string;
            lock?: string;
            force?: boolean;
            newOnly?: boolean;
            clear?: boolean;
            auto?: boolean;
        };
        conversation_compress?: {
            instruction?: string;
        };
        i18n_base?: string;
    }
}
