import { AIMessage } from '@langchain/core/messages';
import type { Session } from 'koishi';
export type ConversationStatus = 'active' | 'archived' | 'deleted' | 'broken';
export type RouteMode = 'personal' | 'shared' | 'custom';
export type ConstraintManageMode = 'anyone' | 'admin';
export type ConstraintPrincipalType = 'user' | 'guild';
export type ConstraintPermission = 'view' | 'manage';
export type ArchiveState = 'ready' | 'restoring' | 'broken';
export interface ConversationCompressionRecord {
    count?: number;
    summary?: string;
    compressedAt?: Date | string | null;
    originalMessageCount?: number;
    remainingMessageCount?: number;
    tokenUsage?: number;
    inputTokens?: number;
    outputTokens?: number;
    reducedTokens?: number;
    reducedPercent?: number;
    [key: string]: unknown;
}
export interface ConversationRecord {
    id: string;
    seq?: number;
    bindingKey: string;
    title: string;
    model: string;
    preset: string;
    chatMode: string;
    createdBy: string;
    createdAt: Date;
    updatedAt: Date;
    lastChatAt?: Date | null;
    status: ConversationStatus;
    latestMessageId?: string | null;
    additional_kwargs?: string | null;
    compression?: string | null;
    archivedAt?: Date | null;
    archiveId?: string | null;
    legacyRoomId?: number | null;
    legacyMeta?: string | null;
    autoTitle?: boolean | null;
}
export interface ConversationListEntry {
    conversation: ConversationRecord;
    displaySeq: number;
}
export interface MessageRecord {
    id: string;
    conversationId: string;
    parentId?: string | null;
    role: string;
    text?: string | null;
    content?: ArrayBuffer | null;
    name?: string | null;
    tool_call_id?: string | null;
    tool_calls?: AIMessage['tool_calls'];
    additional_kwargs_binary?: ArrayBuffer | null;
    response_metadata_binary?: ArrayBuffer | null;
    rawId?: string | null;
    createdAt?: Date | null;
}
export interface ChatLunaMessageMeta {
    recordId?: string;
    createdAt?: string;
    source?: 'user';
}
export interface BindingRecord {
    bindingKey: string;
    activeConversationId?: string | null;
    lastConversationId?: string | null;
    updatedAt: Date;
}
export interface ConstraintRecord {
    id?: number;
    name: string;
    enabled: boolean;
    priority: number;
    createdBy: string;
    createdAt: Date;
    updatedAt: Date;
    platform?: string | null;
    selfId?: string | null;
    guildId?: string | null;
    channelId?: string | null;
    direct?: boolean | null;
    users?: string | null;
    excludeUsers?: string | null;
    routeMode?: RouteMode | null;
    routeKey?: string | null;
    activePresetLane?: string | null;
    defaultModel?: string | null;
    defaultPreset?: string | null;
    defaultChatMode?: string | null;
    fixedModel?: string | null;
    fixedPreset?: string | null;
    fixedChatMode?: string | null;
    lockConversation?: boolean | null;
    allowNew?: boolean | null;
    allowSwitch?: boolean | null;
    allowArchive?: boolean | null;
    allowExport?: boolean | null;
    manageMode?: ConstraintManageMode | null;
}
export interface ArchiveRecord {
    id: string;
    conversationId: string;
    path: string;
    formatVersion: number;
    messageCount: number;
    checksum?: string | null;
    size: number;
    state: ArchiveState;
    createdAt: Date;
    restoredAt?: Date | null;
}
export interface ACLRecord {
    conversationId: string;
    principalType: ConstraintPrincipalType;
    principalId: string;
    permission: ConstraintPermission;
}
export interface MetaRecord {
    key: string;
    value?: string | null;
    updatedAt: Date;
}
export interface ResolvedConstraint {
    routeMode: RouteMode;
    bindingKey: string;
    baseKey: string;
    constraints: ConstraintRecord[];
    activePresetLane?: string | null;
    defaultModel?: string | null;
    defaultPreset?: string | null;
    defaultChatMode?: string | null;
    fixedModel?: string | null;
    fixedPreset?: string | null;
    fixedChatMode?: string | null;
    lockConversation: boolean;
    allowNew: boolean;
    allowSwitch: boolean;
    allowArchive: boolean;
    allowExport: boolean;
    manageMode: ConstraintManageMode;
}
export interface ResolvedConversationContext {
    bindingKey: string;
    presetLane?: string;
    conversation?: ConversationRecord | null;
    binding?: BindingRecord | null;
    effectiveModel?: string | null;
    effectivePreset?: string | null;
    effectiveChatMode?: string | null;
    constraint: ResolvedConstraint;
}
export type ConversationResolveMode = 'context' | 'active' | 'target';
export type ConversationResolutionErrorCode = 'ambiguous_target' | 'target_outside_route';
export declare class ConversationResolutionError extends Error {
    readonly code: ConversationResolutionErrorCode;
    constructor(code: ConversationResolutionErrorCode);
}
export declare class ConversationNotFoundError extends Error {
    constructor();
}
export type ConstraintAction = 'create' | 'switch' | 'rename' | 'delete' | 'archive' | 'restore' | 'export' | 'update' | 'compress';
export declare class ConstraintLockedError extends Error {
    readonly action: ConstraintAction;
    constructor(action: ConstraintAction);
}
export declare class ConstraintDisabledError extends Error {
    readonly action: ConstraintAction;
    constructor(action: ConstraintAction);
}
export type ConstraintFixedField = 'model' | 'preset' | 'chatMode';
export declare class ConstraintFixedError extends Error {
    readonly field: ConstraintFixedField;
    readonly value: string;
    constructor(field: ConstraintFixedField, value: string);
}
export declare class InvalidChatModeError extends Error {
    readonly mode: string;
    constructor(mode: string);
}
export declare class AdminRequiredError extends Error {
    constructor();
}
export interface ResolveConversationOptions {
    mode?: ConversationResolveMode;
    presetLane?: string;
    conversationId?: string;
    bindingKey?: string;
    useRoutePresetLane?: boolean;
    targetConversation?: string;
    includeArchived?: boolean;
    permission?: ConstraintPermission;
    allPresetLanes?: boolean;
}
export interface ConversationResolution extends ResolvedConversationContext {
    mode: ConversationResolveMode;
    conversationId: string | null;
}
export declare function getBaseBindingKey(bindingKey: string): string;
export declare function getPresetLane(bindingKey: string): string;
export declare function computeBaseBindingKey(session: Session, routeMode: RouteMode, routeKey?: string | null): string;
export declare function applyPresetLane(bindingKey: string, presetLane?: string): string;
