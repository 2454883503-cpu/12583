import type { Session } from 'koishi';
export declare function getRequestId(session: Session, conversationId: string): string;
export declare function createRequestId(session: Session, conversationId: string, requestId?: string): string;
export declare function deleteRequestId(session: Session, conversationId: string): void;
