type Encoding = 'buffer' | 'base64' | 'hex';
type BufferType<T extends Encoding> = T extends 'buffer' ? Buffer : T extends 'base64' ? string : T extends 'hex' ? string : never;
export declare function gzipEncode<T extends Encoding = 'buffer'>(data: string, encoding?: T): Promise<BufferType<T>>;
export declare function gzipDecode(data: ArrayBuffer | ArrayBufferView | string, encoding?: 'base64' | 'hex'): Promise<string>;
export declare function bufferToArrayBuffer(buffer: Buffer): ArrayBuffer;
export {};
