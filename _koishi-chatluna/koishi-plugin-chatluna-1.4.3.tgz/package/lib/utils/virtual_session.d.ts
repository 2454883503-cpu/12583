import { type Session } from 'koishi';
import { getMessageContent } from 'koishi-plugin-chatluna/utils/string';
export interface VirtualSessionRouting {
    platform: string;
    selfId: string;
    userId: string;
    username?: string;
    guildId?: string;
    channelId?: string;
    isDirect: boolean;
}
export declare function buildVirtualSession(bot: Session['bot'], routing: VirtualSessionRouting, action: {
    message: Parameters<typeof getMessageContent>[0];
    messageName?: string;
}): Promise<Session<never, never, import("koishi").Context>>;
