import type { BaseMessage, MessageContent, MessageContentComplex, MessageContentImageUrl, MessageContentText } from '@langchain/core/messages';
export declare function markChatLunaUserMessage(msg: BaseMessage): void;
export declare function isChatLunaUserMessage(msg: BaseMessage): boolean;
export declare function isMessageContentImageUrl(message: MessageContentComplex): message is MessageContentImageUrl;
export declare function isMessageContentText(message: MessageContentComplex): message is MessageContentText;
export declare function isMessageContentFileUrl(message: MessageContentComplex): message is MessageContentFileUrl;
export declare function isMessageContentAudio(message: MessageContentComplex): message is MessageContentAudio;
export declare function isMessageContentVideo(message: MessageContentComplex): message is MessageContentVideo;
export declare function isMessageContentComplex(value: unknown): value is MessageContentComplex;
export declare function truncateMessageContentUrls(content: MessageContent, maxLength?: number): MessageContent;
export type MessageContentFileUrl = {
    type: 'file_url';
    file_url: string | {
        url: string;
        mimeType?: string;
    };
};
export type MessageContentAudio = {
    type: 'audio_url';
    audio_url: string | {
        url: string;
        mimeType?: string;
    };
};
export type MessageContentVideo = {
    type: 'video_url';
    video_url: string | {
        url: string;
        mimeType?: string;
    };
};
