import type { Session } from 'koishi';
import { type ConversationRecord, type ResolvedConversationContext } from '../types';
export declare function getFallbackBindingKeys(session: Session, bindingKey: string): string[];
export declare function getLookupKeys(session: Session, bindingKey: string, allPresetLanes?: boolean): string[];
export declare function pickBindingKey(resolved: ResolvedConversationContext, conversation: ConversationRecord): string;
export declare function parseDeleteSeqs(input?: string): number[] | null | undefined;
