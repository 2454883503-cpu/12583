export declare function usageSourceFromStack(stack?: string): string;
