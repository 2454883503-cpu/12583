import type { BaseMessage } from '@langchain/core/messages';
export interface PresetLaneParseResult {
    preset?: string;
    content?: string;
    queryOnly: boolean;
}
export declare function getMessageContent(message: BaseMessage['content']): string;
export declare function parsePresetLaneInput(text: string, aliases: string[]): PresetLaneParseResult | null;
