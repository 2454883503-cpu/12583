import { ModelInfo } from 'koishi-plugin-chatluna/llm-core/platform/types';
export declare function parseRawModelName(modelName: string): [string | undefined, string | undefined];
export declare function modelInfoSupportsElement(info: ModelInfo | undefined, type: 'img' | 'file' | 'video' | 'audio'): boolean;
