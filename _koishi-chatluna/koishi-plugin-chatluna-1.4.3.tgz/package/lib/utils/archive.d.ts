import type { Context } from 'koishi';
import type { ConversationRecord, MessageRecord } from '../types';
import type { ConversationArchivePayload, SerializedMessageRecord } from '../services/types';
export declare function purgeArchivedConversation(ctx: Context, conversation: {
    id: string;
    archiveId?: string | null;
}): Promise<void>;
export declare function removeArchive(ctx: Context, archiveId?: string | null): Promise<void>;
export declare function unbindConversation(ctx: Context, conversationId: string): Promise<void>;
export declare function readArchivePayload(archivePath: string): Promise<ConversationArchivePayload>;
export declare function serializeConversation(conversation: ConversationRecord): ConversationArchivePayload['conversation'];
export declare function deserializeConversation(conversation: ConversationArchivePayload['conversation']): ConversationRecord;
export declare function serializeMessage(message: MessageRecord): SerializedMessageRecord;
export declare function deserializeMessage(message: SerializedMessageRecord): MessageRecord;
