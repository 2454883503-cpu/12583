import { Command, ForkScope, h, Session } from 'koishi';
import { PromiseLikeDisposable } from 'koishi-plugin-chatluna/utils/types';
import type { MessageContent } from '@langchain/core/messages';
export declare function parseElements(source: string): h[];
export declare function parseElements(source: string, partial: true): {
    elements: h[];
    rest: string;
};
export declare function forkScopeToDisposable(scope: ForkScope): PromiseLikeDisposable;
export declare function checkAdmin(session: Session): Promise<boolean>;
export declare function transformToMarkdown(source: string, platform?: string): h[];
export declare function transformToMarkdown(source: TemplateStringsArray, platform: string, ...args: any[]): h[];
export declare function transformMessageContentToElements(content: MessageContent): h[];
export declare function pickForwardMessageId(element: h): string | null;
export declare function isForwardMessageElement(element: h): boolean;
export declare function normalizeForwardMessageId(value: unknown): string | null;
export declare function hideSlashGroups(root: Command): void;
