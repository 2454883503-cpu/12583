import { type ComputedRef } from '@vue/reactivity';
import type { Context } from 'koishi';
import { ChatLunaChatPrompt } from 'koishi-plugin-chatluna/llm-core/chain/prompt';
import type { ChatLunaChatModel } from 'koishi-plugin-chatluna/llm-core/platform/model';
import type { PresetTemplate } from 'koishi-plugin-chatluna/llm-core/prompt';
export interface ComputePresetOptions {
    name: string;
    promptMode?: 'markdown' | 'preset';
    preset?: string;
}
export declare function computePreset(ctx: Context, info: ComputePresetOptions, rawText: string): ComputedRef<PresetTemplate>;
export declare function createChatPrompt(ctx: Context, llm: ChatLunaChatModel, preset: ComputedRef<PresetTemplate>): ChatLunaChatPrompt;
