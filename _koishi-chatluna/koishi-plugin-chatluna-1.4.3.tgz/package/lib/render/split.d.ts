import { BaseMessageChunk } from '@langchain/core/messages';
import { h } from 'koishi';
import type { RenderOptions, SplitMode } from '../types';
export declare class TextStreamSplitter {
    private readonly opts;
    private readonly mode;
    private buf;
    private inContent;
    private stopped;
    constructor(opts: RenderOptions, mode?: SplitMode);
    write(chunk: BaseMessageChunk): string[];
    writeText(text: string): string[];
    flush(): string[];
    private drain;
    private drainParagraph;
    private drainSentence;
}
export declare class MessageElementSplitter {
    private buf;
    write(chunk: BaseMessageChunk): h[];
    writeText(text: string): h[];
    flush(): h[];
}
export declare function extractText(elements: h[]): string;
export declare function splitText(text: string, mode?: SplitMode): string[];
