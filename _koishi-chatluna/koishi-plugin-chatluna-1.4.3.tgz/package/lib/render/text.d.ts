import { h, Schema } from 'koishi';
import { Message, RenderMessage, RenderOptions } from '../types';
import { Renderer } from './base';
import { RenderStreamPlan, RenderStreamSession } from './types';
export declare class TextRenderer extends Renderer {
    render(message: Message, options: RenderOptions): Promise<RenderMessage>;
    getStreamPlan(options: RenderOptions): RenderStreamPlan;
    createStreamSession(options: RenderOptions, plan: RenderStreamPlan): RenderStreamSession;
    schema: Schema<"text", "text">;
}
export declare function transformAndEscape(source: h[], platform?: string): h[];
