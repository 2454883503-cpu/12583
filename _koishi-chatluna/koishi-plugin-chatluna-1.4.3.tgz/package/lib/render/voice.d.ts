import { Schema } from 'koishi';
import { Message, RenderMessage, RenderOptions } from '../types';
import { Renderer } from './base';
import { RenderStreamPlan, RenderStreamSession } from './types';
export declare class VoiceRenderer extends Renderer {
    render(message: Message, options: RenderOptions): Promise<RenderMessage>;
    getStreamPlan(options: RenderOptions): RenderStreamPlan;
    createStreamSession(options: RenderOptions, plan: RenderStreamPlan): RenderStreamSession;
    private _splitMessage;
    private _renderToVoice;
    schema: Schema<"voice", "voice">;
}
