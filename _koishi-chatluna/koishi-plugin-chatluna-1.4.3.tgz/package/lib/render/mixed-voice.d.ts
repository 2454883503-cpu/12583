import { h, Schema } from 'koishi';
import { Message, RenderMessage, RenderOptions } from '../types';
import { Renderer } from './base';
import { RenderStreamPlan, RenderStreamSession } from './types';
export declare class MixedVoiceRenderer extends Renderer {
    render(message: Message, options: RenderOptions): Promise<RenderMessage>;
    getStreamPlan(options: RenderOptions): RenderStreamPlan;
    createStreamSession(options: RenderOptions, plan: RenderStreamPlan): RenderStreamSession;
    renderText(messages: h[], options: RenderOptions): Promise<RenderMessage>;
    renderVoice(messages: h[], options: RenderOptions): Promise<RenderMessage>;
    private _splitMessage;
    private _renderToVoice;
    schema: Schema<"mixed-voice", "mixed-voice">;
}
