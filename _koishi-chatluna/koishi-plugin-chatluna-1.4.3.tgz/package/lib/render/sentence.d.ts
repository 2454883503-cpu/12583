import type { SplitMode } from '../types';
export declare function splitText(text: string, mode?: SplitMode): string[];
export declare function nextTextCut(text: string, flush: boolean): number;
