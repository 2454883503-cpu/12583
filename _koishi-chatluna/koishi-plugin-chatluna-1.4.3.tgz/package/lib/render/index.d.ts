import { Context } from 'koishi';
import { ChainMiddlewareContext } from '../chains/chain';
import { Config } from '../config';
import { Message, RenderMessage, RenderOptions } from '../types';
import { Renderer } from './base';
import { ReplyStream, ReplyStreamOptions } from './stream';
export declare class DefaultRenderer {
    protected readonly ctx: Context;
    protected readonly config: Config;
    defaultOptions: RenderOptions;
    private renderers;
    constructor(ctx: Context, config: Config);
    render(message: Message, options?: RenderOptions): Promise<RenderMessage[]>;
    createStream(context: ChainMiddlewareContext, options: ReplyStreamOptions): ReplyStream;
    private renderAdditionalMessages;
    addRenderer(type: string, renderer: (ctx: Context, config: Config) => Renderer): () => void;
    removeRenderer(type: string): void;
    getRenderer(type: string): Renderer;
    updateSchema(): void;
    private _getAllRendererScheme;
    get rendererTypeList(): string[];
}
export * from './base';
export * from './types';
