import type { Context, h } from 'koishi';
import type { ChainMiddlewareContext } from '../chains/chain';
import type { Config } from '../config';
import type { Message, RenderMessage, RenderOptions } from '../types';
import type { Renderer } from './base';
import type { ReplyFrame } from './types';
export interface ReplyStreamOptions {
    enabled: boolean;
    send?: boolean;
    censor?: boolean;
    renderOptions?: RenderOptions;
    renderMessage?: (message: Message) => Promise<RenderMessage[]>;
    renderAdditional?: (message: Message) => Promise<h[][]>;
}
export declare class ReplyStream {
    private readonly ctx;
    private readonly context;
    private readonly renderer;
    private mode;
    private stream;
    private queue;
    private firstChunk;
    private finalMessage;
    private send;
    private sentAdditional;
    private closed;
    private moderated;
    private renderMessage;
    private renderAdditional?;
    constructor(ctx: Context, config: Config, context: ChainMiddlewareContext, renderer: Renderer, opts: ReplyStreamOptions);
    write(frame: ReplyFrame): Promise<void>;
    end(frame?: ReplyFrame): Promise<void>;
    private sendMessage;
    private sendAdditional;
    private sendElements;
    private censor;
    private finish;
}
