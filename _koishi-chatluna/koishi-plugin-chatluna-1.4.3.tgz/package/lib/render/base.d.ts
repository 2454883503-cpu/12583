import { BaseMessageChunk } from '@langchain/core/messages';
import { Context, h, Schema } from 'koishi';
import { Message, RenderMessage, RenderOptions } from '../types';
import { RenderStreamPlan, RenderStreamSession } from './types';
import { TextStreamSplitter } from './split';
export declare abstract class Renderer {
    protected readonly ctx: Context;
    constructor(ctx: Context);
    abstract render(message: Message, options: RenderOptions): Promise<RenderMessage>;
    getStreamPlan(_options: RenderOptions): RenderStreamPlan;
    createStreamSession(_options: RenderOptions, _plan: RenderStreamPlan): RenderStreamSession;
    renderStreamMessage(stream: RenderStreamSession, message: Message, options: RenderOptions): Promise<h[] | null>;
    abstract schema: Schema<string, string>;
}
export declare abstract class BufferedRenderStreamSession implements RenderStreamSession {
    protected readonly options: RenderOptions;
    protected readonly plan: RenderStreamPlan;
    protected text: string;
    protected splitter: TextStreamSplitter;
    constructor(options: RenderOptions, plan: RenderStreamPlan, mode?: import("..").SplitMode);
    write(chunk: BaseMessageChunk): Promise<h[]>;
    flush(): Promise<h[]>;
    protected writeText(text: string): Promise<h[]>;
    protected renderParts(parts: string[]): Promise<h[]>;
    protected abstract renderText(text: string): Promise<h[]> | h[];
}
