import type { Context } from 'koishi';
import type { Config } from '../config';
export declare const BUILTIN_SCHEMA_VERSION = 1;
export declare function runRoomToConversationMigration(ctx: Context, config: Config): any;
export declare function ensureMigrationValidated(ctx: Context, config: Config): any;
