import type { Context } from 'koishi';
import type { LegacyTableRetention } from './types';
export type { LegacyTableRetention } from './types';
export declare const LEGACY_SCHEMA_SENTINEL = "data/chatluna/temp/legacy-schema-disabled.json";
export declare const LEGACY_MIGRATION_TABLES: readonly ["chathub_room_member", "chathub_room_group_member", "chathub_user", "chathub_room", "chathub_message", "chathub_conversation"];
export declare const LEGACY_RUNTIME_TABLES: readonly [];
export declare const LEGACY_RETENTION_META_KEY = "legacy_table_retention";
export declare function createLegacyTableRetention(state: LegacyTableRetention['state']): {
    state: "migration-visible" | "purged";
    migrationTables: ("chathub_conversation" | "chathub_message" | "chathub_room" | "chathub_room_member" | "chathub_room_group_member" | "chathub_user")[];
    runtimeTables: never[];
};
export declare function getLegacySchemaSentinel(baseDir: string): string;
export declare function getLegacySchemaSentinelDir(baseDir: string): string;
export declare function defineLegacyMigrationTables(ctx: Context, force?: boolean): void;
export declare function isMissingTableError(error: unknown): boolean;
export declare function dropTableIfExists(ctx: Context, table: string): Promise<boolean>;
export declare function purgeLegacyTables(ctx: Context): Promise<void>;
