import type { Context } from 'koishi';
import type { Config } from '../config';
import type { LegacyRoomGroupRecord, LegacyRoomMemberRecord, LegacyRoomRecord, LegacyUserRecord } from '../services/types';
import type { MigrationValidationResult } from './types';
export type { MigrationValidationResult } from './types';
export { getLegacySchemaSentinel, dropTableIfExists, getLegacySchemaSentinelDir, LEGACY_MIGRATION_TABLES, LEGACY_RETENTION_META_KEY, LEGACY_RUNTIME_TABLES, LEGACY_SCHEMA_SENTINEL, createLegacyTableRetention, purgeLegacyTables } from './legacy_tables';
export declare function createPassedValidationResult(): MigrationValidationResult;
export declare function validateRoomMigration(ctx: Context, _config: Config): Promise<{
    passed: boolean;
    checkedAt: string;
    conversation: {
        legacy: number;
        migrated: number;
        matched: boolean;
    };
    message: {
        legacy: number;
        migrated: number;
        matched: boolean;
    };
    latestMessageId: {
        missingConversationIds: string[];
        matched: boolean;
    };
    bindingKey: {
        inconsistentConversationIds: string[];
        matched: boolean;
    };
    binding: {
        missingBindingKeys: string[];
        missingConversationIds: string[];
        matched: boolean;
    };
    acl: {
        expected: number;
        migrated: number;
        missing: string[];
        matched: boolean;
    };
}>;
export declare function readMetaValue<T>(ctx: Context, key: string): Promise<T>;
export declare function writeMetaValue(ctx: Context, key: string, value: unknown): Promise<void>;
export declare function createLegacyBindingKey(user: LegacyUserRecord, routeModes: Map<string, 'shared' | 'personal'>): string;
export declare function isComplexRoom(room: LegacyRoomRecord, members: LegacyRoomMemberRecord[], groups: LegacyRoomGroupRecord[]): boolean;
export declare function filterValidRooms(rooms: LegacyRoomRecord[]): LegacyRoomRecord[];
export declare function aclKey(conversationId: string, principalType: string, principalId: string, permission: string): string;
export declare function resolveRoomBindingKey(room: LegacyRoomRecord, members: LegacyRoomMemberRecord[], groups: LegacyRoomGroupRecord[], routeModes: Map<string, 'shared' | 'personal'>): string;
export declare function inferLegacyGroupRouteModes(users: LegacyUserRecord[], rooms: LegacyRoomRecord[], groups: LegacyRoomGroupRecord[]): Map<string, "shared" | "personal">;
