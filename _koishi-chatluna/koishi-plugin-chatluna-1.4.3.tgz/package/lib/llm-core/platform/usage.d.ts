import type { UsageMetadata } from '@langchain/core/messages';
import type { Context } from 'koishi';
export declare function createModelUsageReporter(ctx: Context, platform: string, model: string, stack?: string): ModelUsageReporter;
export declare function warmupTokenEncoder(): Promise<void>;
export declare function estimateTextTokens(input: string | string[]): Promise<number>;
declare module 'koishi' {
    interface Events {
        'chatluna/model-usage'(payload: ModelUsagePayload): Promise<void>;
    }
}
export type ModelUsageCallType = 'llm' | 'embeddings' | 'reranker';
export interface ModelUsageContext {
    chatPlatform?: string;
    conversationId?: string;
    requestId?: string;
    userId?: string;
    guildId?: string;
}
export interface ModelUsagePayload {
    source: string;
    callType: ModelUsageCallType;
    platform: string;
    model: string;
    usageMetadata: UsageMetadata;
    localInputTokens?: number;
    localOutputTokens?: number;
    estimated: boolean;
    success: boolean;
    createdAt: Date;
    timing?: ModelUsageTiming;
    context?: ModelUsageContext;
}
export interface ModelUsageTiming {
    ttftMs?: number;
    totalMs?: number;
    tps?: number;
}
export type ModelUsageInput = Omit<ModelUsagePayload, 'source' | 'createdAt' | 'platform' | 'model' | 'usageMetadata' | 'estimated' | 'success'> & {
    createdAt?: Date;
    platform?: string;
    model?: string;
    usageMetadata?: UsageMetadata;
    estimated?: boolean;
    success?: boolean;
};
export interface ModelUsageReporter {
    (usage: ModelUsageInput): Promise<void> | void;
}
export interface EmbeddingsUsageResult {
    data: number[] | number[][];
    usage?: UsageMetadata;
}
export interface UsageContext {
    source: string;
    chatPlatform?: string;
    conversationId?: string;
    requestId?: string;
    userId?: string;
    guildId?: string;
}
export type EmbeddingsResult = number[] | number[][] | EmbeddingsUsageResult;
export interface RerankerUsageResult {
    results: RerankerResult[];
    usage?: UsageMetadata;
}
export interface RerankerResult {
    index: number;
    relevanceScore: number;
}
