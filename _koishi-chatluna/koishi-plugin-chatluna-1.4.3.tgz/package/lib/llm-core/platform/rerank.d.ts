import { DocumentInterface } from '@langchain/core/documents';
import { BaseDocumentCompressor } from '@langchain/core/retrievers/document_compressors';
import { AsyncCaller, AsyncCallerParams } from '@langchain/core/utils/async_caller';
import { RerankerRequester } from 'koishi-plugin-chatluna/llm-core/platform/api';
import type { ModelUsageReporter } from 'koishi-plugin-chatluna/llm-core/platform/usage';
export interface ChatLunaRerankerParams extends AsyncCallerParams {
    timeout?: number;
    maxRetries?: number;
    client: RerankerRequester;
    model?: string;
    topN?: number;
    maxChunksPerDoc?: number;
    usageReporter?: ModelUsageReporter;
}
export declare class ChatLunaReranker extends BaseDocumentCompressor {
    modelName: string;
    topN: number;
    maxChunksPerDoc?: number;
    timeout: number;
    caller: AsyncCaller;
    private _client;
    private _report?;
    constructor(fields: ChatLunaRerankerParams);
    compressDocuments(documents: DocumentInterface[], query: string): Promise<DocumentInterface[]>;
    rerank(documents: (DocumentInterface | string | Record<string, string>)[], query: string, options?: {
        model?: string;
        topN?: number;
        maxChunksPerDoc?: number;
    }): Promise<{
        index: number;
        relevanceScore: number;
    }[]>;
    private _rerankWithRetry;
    private _reportUsage;
    private _reportFailedUsage;
}
