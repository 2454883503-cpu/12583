import type { UsageMetadata } from '@langchain/core/messages';
import { ChatGeneration, ChatGenerationChunk } from '@langchain/core/outputs';
import type { ModelUsageTiming } from 'koishi-plugin-chatluna/llm-core/platform/usage';
/**
 * Typed carrier for ChatLuna invocation metrics (usage + timing). Attached to
 * generation results by requesters and read by the model for reporting. The
 * raw key is encapsulated by attachInvocationMetrics/readInvocationMetrics so
 * adapters never touch it directly.
 */
export interface ChatLunaInvocationMetrics {
    usageMetadata?: UsageMetadata;
    timing?: ModelUsageTiming;
}
export declare function attachInvocationMetrics(chunk: ChatGeneration | ChatGenerationChunk, metrics: ChatLunaInvocationMetrics): void;
export declare function readInvocationMetrics(chunk?: ChatGeneration): ChatLunaInvocationMetrics;
export declare const MIN_LATENCY_MS = 10;
export declare function createModelUsageTiming(start: number, firstAt?: number, usage?: UsageMetadata): ModelUsageTiming;
/**
 * Collects timing + usage across a streaming completion and attaches a single
 * ChatLunaInvocationMetrics payload to the trailing chunk. Encapsulates the
 * mutable state and BaseMessage->AIMessageChunk casts out of completionStream.
 */
export declare class StreamMetricsTracker {
    private readonly start;
    private firstAt?;
    private usage?;
    private readonly kwargs;
    private readonly metadata;
    private readonly info;
    observe(chunk: ChatGenerationChunk): void;
    attachTo(chunk: ChatGenerationChunk): ChatGenerationChunk;
}
