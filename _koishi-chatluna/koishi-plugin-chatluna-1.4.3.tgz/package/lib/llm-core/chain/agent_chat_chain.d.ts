import { ChainValues } from '@langchain/core/utils/types';
import { ChatLunaLLMCallArg, ChatLunaLLMChainWrapper, SystemPrompts } from 'koishi-plugin-chatluna/llm-core/chain/base';
import { ChatLunaBaseEmbeddings, ChatLunaChatModel } from 'koishi-plugin-chatluna/llm-core/platform/model';
import { ChatLunaTool } from 'koishi-plugin-chatluna/llm-core/platform/types';
import { AgentRunner, ToolMask } from 'koishi-plugin-chatluna/llm-core/agent';
import { BufferMemory } from 'koishi-plugin-chatluna/llm-core/memory/langchain';
import { PresetTemplate } from 'koishi-plugin-chatluna/llm-core/prompt';
import { ChatLunaChatPrompt } from 'koishi-plugin-chatluna/llm-core/chain/prompt';
import type { ChatLunaPromptRenderService } from 'koishi-plugin-chatluna/services/chat';
import { ComputedRef } from '@vue/reactivity';
import type { ChatLunaContextManagerService } from 'koishi-plugin-chatluna/llm-core/prompt';
export interface ChatLunaPluginChainInput {
    prompt: ChatLunaChatPrompt;
    historyMemory: BufferMemory;
    embeddings: ChatLunaBaseEmbeddings;
    agentMode?: 'tool-calling' | 'react';
    variableService: ChatLunaPromptRenderService;
    preset: ComputedRef<PresetTemplate>;
    contextManager: ChatLunaContextManagerService;
    toolMask?: ToolMask;
}
export declare class ChatLunaPluginChain extends ChatLunaLLMChainWrapper implements ChatLunaPluginChainInput {
    runner: ComputedRef<AgentRunner>;
    historyMemory: BufferMemory;
    systemPrompts?: SystemPrompts;
    llm: ChatLunaChatModel;
    embeddings: ChatLunaBaseEmbeddings;
    tools: ComputedRef<ChatLunaTool[]>;
    variableService: ChatLunaPromptRenderService;
    prompt: ChatLunaChatPrompt;
    preset: ComputedRef<PresetTemplate>;
    contextManager: ChatLunaContextManagerService;
    agentMode?: 'tool-calling' | 'react';
    toolMask?: ToolMask;
    private _toolsRef;
    constructor({ historyMemory, prompt, llm, tools, preset, embeddings, agentMode, contextManager, toolMask }: ChatLunaPluginChainInput & {
        tools: ComputedRef<ChatLunaTool[]>;
        llm: ChatLunaChatModel;
    });
    static fromLLMAndTools(llm: ChatLunaChatModel, tools: ComputedRef<ChatLunaTool[]>, { historyMemory, preset, embeddings, agentMode, variableService, contextManager, toolMask }: Omit<ChatLunaPluginChainInput, 'prompt'>): ChatLunaPluginChain;
    private _createRunner;
    call(arg: ChatLunaLLMCallArg): Promise<ChainValues>;
    get model(): ChatLunaChatModel;
}
