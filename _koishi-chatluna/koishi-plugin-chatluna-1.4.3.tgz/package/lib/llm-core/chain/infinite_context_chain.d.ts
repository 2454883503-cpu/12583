import { type UsageMetadata } from '@langchain/core/messages';
import { ChatLunaChatModel } from 'koishi-plugin-chatluna/llm-core/platform/model';
export interface CompressChunkResult {
    text: string;
    usageMetadata?: UsageMetadata;
}
export declare function compressChunk(model: ChatLunaChatModel, transcript: string, conversationId: string, signal?: AbortSignal, instruction?: string): Promise<CompressChunkResult | null>;
