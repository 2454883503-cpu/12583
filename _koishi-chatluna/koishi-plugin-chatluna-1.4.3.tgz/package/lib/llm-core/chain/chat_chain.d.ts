import { ChainValues } from '@langchain/core/utils/types';
import { ChatLunaLLMCallArg, ChatLunaLLMChain, ChatLunaLLMChainWrapper } from 'koishi-plugin-chatluna/llm-core/chain/base';
import { ChatLunaChatModel } from 'koishi-plugin-chatluna/llm-core/platform/model';
import { BufferMemory } from 'koishi-plugin-chatluna/llm-core/memory/langchain';
import { PresetTemplate } from 'koishi-plugin-chatluna/llm-core/prompt';
import type { ChatLunaPromptRenderService } from 'koishi-plugin-chatluna/services/chat';
import type { ChatLunaContextManagerService } from 'koishi-plugin-chatluna/llm-core/prompt';
import { ComputedRef } from '@vue/reactivity';
export interface ChatLunaChatChainInput {
    botName: string;
    preset: ComputedRef<PresetTemplate>;
    humanMessagePrompt?: string;
    historyMemory: BufferMemory;
    variableService: ChatLunaPromptRenderService;
    contextManager: ChatLunaContextManagerService;
}
export declare class ChatLunaChatChain extends ChatLunaLLMChainWrapper implements ChatLunaChatChainInput {
    botName: string;
    chain: ChatLunaLLMChain;
    historyMemory: BufferMemory;
    preset: ComputedRef<PresetTemplate>;
    variableService: ChatLunaPromptRenderService;
    contextManager: ChatLunaContextManagerService;
    constructor({ botName, historyMemory, preset, chain, variableService, contextManager }: ChatLunaChatChainInput & {
        chain: ChatLunaLLMChain;
    });
    static fromLLM(llm: ChatLunaChatModel, { botName, historyMemory, preset, variableService, contextManager }: ChatLunaChatChainInput): ChatLunaLLMChainWrapper;
    call({ message, stream, events, session, conversationId, requestId, source, variables, signal, maxToken, maxTokenLimit, callbacks }: ChatLunaLLMCallArg): Promise<ChainValues>;
    get model(): ChatLunaChatModel;
}
