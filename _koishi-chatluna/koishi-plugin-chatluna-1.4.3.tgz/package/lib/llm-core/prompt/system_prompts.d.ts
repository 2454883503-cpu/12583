import { ChatLunaContextManagerService, PromptPipelineMiddleware } from './context_manager';
import { countMessagesTokens, countMessageTokens } from 'koishi-plugin-chatluna/llm-core/utils/count_tokens';
export { countMessageTokens, countMessagesTokens };
/**
 * Renders the preset template into system messages and pushes them onto
 * the result list.  Also handles the optional `instructions` partial.
 *
 * Populates `runtime._conversationSummaryPrompt` for later use by the
 * long_history middleware.
 */
export declare function createSystemPromptsMiddleware(): PromptPipelineMiddleware;
/**
 * Register the system_prompts pipeline middleware on the context manager.
 */
export declare function registerSystemPromptsMiddleware(contextManager: ChatLunaContextManagerService): () => void;
