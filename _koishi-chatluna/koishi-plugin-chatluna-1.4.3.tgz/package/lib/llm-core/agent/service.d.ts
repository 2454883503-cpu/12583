import type { Embeddings } from '@langchain/core/embeddings';
import { type ComputedRef } from '@vue/reactivity';
import type { ChatLunaChatPrompt } from '../chain/prompt';
import type { ChatLunaBaseEmbeddings, ChatLunaChatModel } from '../platform/model';
import type { ChatLunaTool } from '../platform/types';
import type { PresetTemplate } from '../prompt';
import type { ToolMask } from './types';
export interface CreateChatLunaAgentOptions {
    id?: string;
    name?: string;
    description?: string;
    model: string | ChatLunaChatModel | ComputedRef<ChatLunaChatModel | undefined>;
    embeddings?: string | ChatLunaBaseEmbeddings | ComputedRef<Embeddings | undefined>;
    tools?: string[] | ChatLunaTool[] | ComputedRef<ChatLunaTool[]>;
    mode?: 'tool-calling' | 'react';
    preset?: string | ComputedRef<PresetTemplate>;
    system?: string;
    prompt?: ChatLunaChatPrompt;
    maxSteps?: number;
    handleParsingErrors?: boolean | string | ((e: Error) => string);
    instructions?: string | ComputedRef<string | undefined>;
    returnIntermediateSteps?: boolean;
    toolMask?: ToolMask;
}
export declare function resolveAgentModel(input: CreateChatLunaAgentOptions['model'], createChatModel: (fullModelName: string) => Promise<ComputedRef<ChatLunaChatModel | undefined>>): Promise<ComputedRef<ChatLunaChatModel>>;
export declare function resolveAgentEmbeddings(input: CreateChatLunaAgentOptions['embeddings'], createEmbeddings: (fullModelName: string) => Promise<ComputedRef<Embeddings | undefined>>, fallback: string): Promise<ChatLunaBaseEmbeddings>;
export declare function resolveAgentTools(input: CreateChatLunaAgentOptions['tools'], getTool: (name: string) => ChatLunaTool): ComputedRef<ChatLunaTool[]>;
export declare function resolveAgentPreset(options: CreateChatLunaAgentOptions, getPreset: (name: string) => ComputedRef<PresetTemplate>): {
    preset: ComputedRef<PresetTemplate>;
    instructions: ComputedRef<string>;
};
