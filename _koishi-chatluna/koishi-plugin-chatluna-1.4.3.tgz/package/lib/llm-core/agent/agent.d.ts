import type { Callbacks } from '@langchain/core/callbacks/manager';
import { BaseMessage, BaseMessageChunk, HumanMessage } from '@langchain/core/messages';
import { StructuredTool } from '@langchain/core/tools';
import { type ComputedRef } from '@vue/reactivity';
import { type Session } from 'koishi';
import { z } from 'zod';
import type { ChatLunaChatPrompt } from '../chain/prompt';
import type { ChatLunaBaseEmbeddings, ChatLunaChatModel } from 'koishi-plugin-chatluna/llm-core/platform/model';
import type { ChatLunaTool } from 'koishi-plugin-chatluna/llm-core/platform/types';
import type { PresetTemplate } from '../prompt';
import type { AgentRunnerOutput } from './executor';
import type { AgentEvent, MessageQueue, SubagentContext, ToolMask } from './types';
export interface CreateAgentOptions {
    id?: string;
    name?: string;
    description?: string;
    llm: ComputedRef<ChatLunaChatModel>;
    embeddings: ChatLunaBaseEmbeddings;
    tools: ComputedRef<ChatLunaTool[]>;
    prompt: ChatLunaChatPrompt;
    mode?: 'tool-calling' | 'react';
    maxSteps?: number;
    handleParsingErrors?: boolean | string | ((e: Error) => string);
    instructions?: ComputedRef<string | undefined>;
    returnIntermediateSteps?: boolean;
    toolMask?: ToolMask;
}
export interface AgentGenerateOptions {
    prompt: string | HumanMessage;
    session?: Session;
    conversationId: string;
    requestId: string;
    source?: 'chatluna' | 'character';
    history?: BaseMessage[];
    variables?: Record<string, any>;
    signal?: AbortSignal;
    maxToken?: number;
    maxTokenLimit?: number;
    messageQueue?: MessageQueue;
    pauseGate?: (signal?: AbortSignal) => Promise<void>;
    toolMask?: ToolMask;
    subagentContext?: SubagentContext;
    onStep?: (event: AgentEvent) => Promise<void> | void;
    onToken?: (token: string) => Promise<void> | void;
    onChunk?: (chunk: BaseMessageChunk) => Promise<void> | void;
    callbacks?: Callbacks;
}
export interface AgentStream {
    text: AsyncIterable<string>;
    steps: AsyncIterable<AgentEvent>;
    result: Promise<AgentRunnerOutput>;
}
export interface AgentToolOptions {
    name?: string;
    description?: string;
}
export interface ChatLunaAgent {
    id: string;
    name: string;
    description: string;
    generate(input: AgentGenerateOptions): Promise<AgentRunnerOutput>;
    stream(input: AgentGenerateOptions): Promise<AgentStream>;
    asTool(options?: AgentToolOptions): StructuredTool;
}
export interface CreateAgentToolOptions extends AgentToolOptions {
    schema?: z.ZodTypeAny;
}
export declare function createAgent(options: CreateAgentOptions): ChatLunaAgent;
export declare function createAgentTool(agent: ChatLunaAgent, options?: CreateAgentToolOptions): StructuredTool;
export declare function createPromptPreset(name: string, system?: string, preset?: ComputedRef<PresetTemplate>): ComputedRef<PresetTemplate>;
