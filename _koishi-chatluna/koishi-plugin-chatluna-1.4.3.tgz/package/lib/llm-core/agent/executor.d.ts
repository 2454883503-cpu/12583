import { Runnable, RunnableConfig } from '@langchain/core/runnables';
import type { StructuredTool } from '@langchain/core/tools';
import type { ChainValues } from '@langchain/core/utils/types';
import type { AgentExecutorInput, AgentExecutorOutput } from './legacy-executor';
export { coerceToAgentObservation, LegacyAgentExecutor, observationToMessageContent, runAgent, toToolInputErrorObservation, type AgentExecutorInput, type AgentExecutorOutput, type RunAgentOptions } from './legacy-executor';
export declare class AgentRunner extends Runnable<ChainValues, AgentRunnerOutput> {
    lc_serializable: boolean;
    lc_namespace: string[];
    agent: Runnable;
    tools: StructuredTool[];
    returnIntermediateSteps: boolean;
    maxIterations?: number;
    handleParsingErrors?: boolean | string | ((e: Error) => string);
    handleToolRuntimeErrors?: (e: Error) => string;
    constructor(fields: AgentRunnerInput);
    static fromAgentAndTools(fields: AgentRunnerInput): AgentRunner;
    private _run;
    invoke(input: ChainValues, options?: RunnableConfig): Promise<AgentRunnerOutput>;
    _streamIterator(input: ChainValues, options?: RunnableConfig): AsyncGenerator<AgentRunnerOutput>;
}
export declare const AgentExecutor: typeof AgentRunner;
export type AgentExecutor = AgentRunner;
export type AgentRunnerInput = AgentExecutorInput;
export type AgentRunnerOutput = AgentExecutorOutput;
