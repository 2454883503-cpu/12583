import type { AgentTaskToolRuntime, CreateTaskToolOptions } from './types';
export declare function createTaskTool(options: CreateTaskToolOptions): AgentTaskToolRuntime;
