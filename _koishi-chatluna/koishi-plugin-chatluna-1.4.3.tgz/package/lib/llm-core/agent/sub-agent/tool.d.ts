import { SystemMessage } from '@langchain/core/messages';
import { StructuredTool } from '@langchain/core/tools';
import { z } from 'zod';
import type { AgentTaskDescriptor, AgentTaskInput, AgentTaskToolRuntime } from './types';
import type { ChatLunaToolRunnable } from '../../platform/types';
export declare function buildTaskToolDescription(): string;
export declare function renderAvailableAgents(agents: AgentTaskDescriptor[], dir?: string, location?: 'local' | 'remote'): SystemMessage;
declare class AgentTaskTool extends StructuredTool {
    private _runtime;
    name: string;
    description: string;
    schema: z.ZodEffects<z.ZodObject<{
        action: z.ZodOptional<z.ZodEnum<["run", "status", "list", "list_all", "message", "stop"]>>;
        agent: z.ZodOptional<z.ZodString>;
        id: z.ZodOptional<z.ZodString>;
        prompt: z.ZodOptional<z.ZodString>;
        goal: z.ZodOptional<z.ZodString>;
        reason: z.ZodOptional<z.ZodString>;
        background: z.ZodOptional<z.ZodBoolean>;
        message: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        message?: string;
        id?: string;
        prompt?: string;
        action?: "message" | "status" | "list" | "run" | "stop" | "list_all";
        agent?: string;
        background?: boolean;
        goal?: string;
        reason?: string;
    }, {
        message?: string;
        id?: string;
        prompt?: string;
        action?: "message" | "status" | "list" | "run" | "stop" | "list_all";
        agent?: string;
        background?: boolean;
        goal?: string;
        reason?: string;
    }>, {
        message?: string;
        id?: string;
        prompt?: string;
        action?: "message" | "status" | "list" | "run" | "stop" | "list_all";
        agent?: string;
        background?: boolean;
        goal?: string;
        reason?: string;
    }, {
        message?: string;
        id?: string;
        prompt?: string;
        action?: "message" | "status" | "list" | "run" | "stop" | "list_all";
        agent?: string;
        background?: boolean;
        goal?: string;
        reason?: string;
    }>;
    constructor(name: string, _runtime: AgentTaskToolRuntime);
    _call(input: AgentTaskInput, _: unknown, runConfig?: ChatLunaToolRunnable): Promise<string>;
}
export { AgentTaskTool };
