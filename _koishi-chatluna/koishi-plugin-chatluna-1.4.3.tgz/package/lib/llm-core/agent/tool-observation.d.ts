import { StructuredTool, ToolInputParsingException } from '@langchain/core/tools';
import { AgentAction, AgentObservation } from './types';
export interface AgentLoopState {
    calls: Map<string, number>;
    failures: Map<string, number>;
    results: Map<string, {
        hash: string;
        count: number;
    }>;
    busy: Map<string, number>;
}
export declare function createAgentLoopState(): AgentLoopState;
export declare function repairToolAction(action: AgentAction, tools: Record<string, StructuredTool>): AgentAction;
export declare function applyLoopGuidance(state: AgentLoopState | undefined, action: AgentAction, observation: AgentObservation, failed: boolean): AgentObservation;
export declare function coerceToAgentObservation(observation: unknown, toolName?: string): AgentObservation;
export declare function toToolInputErrorObservation(handleParsingErrors: boolean | string | ((e: Error) => string), error: ToolInputParsingException): AgentObservation;
export declare function toOutput(value: unknown): string;
export declare function observationToMessageContent(observation: AgentObservation): string | import("./types").AgentObservationComplexContent[];
