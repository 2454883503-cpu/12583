import { CallbackManagerForChainRun } from '@langchain/core/callbacks/manager';
import { AIMessage } from '@langchain/core/messages';
import { Runnable, type RunnableConfig } from '@langchain/core/runnables';
import { StructuredTool } from '@langchain/core/tools';
import type { ChainValues } from '@langchain/core/utils/types';
import { BaseChain, ChainInputs } from 'koishi-plugin-chatluna/llm-core/chain/base';
import { AgentEvent, AgentRuntimeConfigurable, AgentStep, MessageQueue } from './types';
export declare function runAgent(options: RunAgentOptions): AsyncGenerator<AgentEvent>;
export declare function emitAgentEvent(runManager: CallbackManagerForChainRun | undefined, configurable: AgentRuntimeConfigurable, event: AgentEvent): Promise<void>;
export declare class LegacyAgentExecutor extends BaseChain<ChainValues, AgentExecutorOutput> {
    lc_serializable: boolean;
    agent: Runnable;
    tools: StructuredTool[];
    returnIntermediateSteps: boolean;
    maxIterations?: number;
    handleParsingErrors?: boolean | string | ((e: Error) => string);
    handleToolRuntimeErrors?: (e: Error) => string;
    constructor(fields: AgentExecutorInput);
    get inputKeys(): string[];
    get outputKeys(): string[];
    static fromAgentAndTools(fields: AgentExecutorInput): LegacyAgentExecutor;
    _call(inputs: ChainValues, runManager?: CallbackManagerForChainRun, config?: RunnableConfig): Promise<AgentExecutorOutput>;
    _chainType(): "agent_executor";
}
export interface RunAgentOptions {
    agent: Runnable;
    tools: StructuredTool[];
    input: ChainValues;
    messageQueue?: MessageQueue;
    signal?: AbortSignal;
    maxIterations?: number;
    handleParsingErrors?: boolean | string | ((e: Error) => string);
    handleToolRuntimeErrors?: (e: Error) => string;
    config?: RunnableConfig;
}
export interface AgentExecutorInput extends ChainInputs {
    agent: Runnable;
    tools: StructuredTool[];
    returnIntermediateSteps?: boolean;
    maxIterations?: number;
    handleParsingErrors?: boolean | string | ((e: Error) => string);
    handleToolRuntimeErrors?: (e: Error) => string;
}
export interface AgentExecutorOutput extends ChainValues {
    output: string;
    intermediateSteps?: AgentStep[];
    message: AIMessage;
}
export { coerceToAgentObservation, observationToMessageContent, toToolInputErrorObservation } from './tool-observation';
