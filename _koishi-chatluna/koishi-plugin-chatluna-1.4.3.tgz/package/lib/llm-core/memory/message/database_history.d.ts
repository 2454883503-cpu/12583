import { Context } from 'koishi';
import { BaseMessage } from '@langchain/core/messages';
import { BaseChatMessageHistory } from '@langchain/core/chat_history';
import type { AgentStep } from '../../agent/types';
import type { ChatLunaService } from '../../../services/chat';
export declare class KoishiChatMessageHistory extends BaseChatMessageHistory {
    private _maxMessagesCount;
    private readonly chatluna;
    lc_namespace: string[];
    conversationId: string;
    private _ctx;
    private _latestId;
    private _serializedChatHistory;
    private _chatHistory;
    private _additional_kwargs;
    private _updatedAt;
    constructor(ctx: Context, conversationId: string, _maxMessagesCount: number, chatluna: ChatLunaService);
    get additionalArgs(): Record<string, string>;
    getMessages(): Promise<BaseMessage[]>;
    addUserMessage(message: string): Promise<void>;
    addAIChatMessage(message: string): Promise<void>;
    addMessage(message: BaseMessage): Promise<void>;
    addMessages(messages: BaseMessage[]): Promise<void>;
    addAgentToolBatch(steps: AgentStep[]): Promise<void>;
    replaceMessages(messages: BaseMessage[]): Promise<void>;
    clear(): Promise<void>;
    delete(): Promise<void>;
    updateAdditionalArg(key: string, value: string): Promise<void>;
    getAdditionalArg(key: string): Promise<string>;
    getAdditionalArgs(): Promise<{
        [key: string]: string;
    }>;
    deleteAdditionalArg(key: string): Promise<void>;
    removeAllToolAndFunctionMessages(): Promise<BaseMessage[]>;
    overrideAdditionalArgs(kwargs: {
        [key: string]: string;
    }): Promise<void>;
    private getLatestUpdateTime;
    private _loadMessages;
    private _loadConversation;
    loadConversation(): Promise<void>;
    private _trimMessages;
    private _saveConversation;
}
