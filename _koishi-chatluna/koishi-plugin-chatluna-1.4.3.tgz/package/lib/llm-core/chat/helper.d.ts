import { AIMessage } from '@langchain/core/messages';
import { ComputedRef } from '@vue/reactivity';
import { ChatLunaChatModel } from 'koishi-plugin-chatluna/llm-core/platform/model';
import { PlatformService } from 'koishi-plugin-chatluna/llm-core/platform/service';
import { ModelInfo } from 'koishi-plugin-chatluna/llm-core/platform/types';
import type { ChatLunaService } from '../../services/chat';
export declare function createDisplayResponse(responseMessage: AIMessage): AIMessage;
export declare function initEmbeddings(service: PlatformService, model: string | undefined): Promise<ComputedRef<import("koishi-plugin-chatluna/llm-core/model/in_memory").EmptyEmbeddings>>;
export declare function initModel(chatluna: ChatLunaService, llmPlatform: string, llmModelName: string): Promise<[
    ComputedRef<ChatLunaChatModel>,
    ComputedRef<ModelInfo | undefined>
]>;
export declare function supportChatMode(modelInfo: ModelInfo, chatMode: string): boolean;
