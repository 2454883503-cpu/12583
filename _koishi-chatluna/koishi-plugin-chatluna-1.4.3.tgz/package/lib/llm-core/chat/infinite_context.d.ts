import { BaseMessage } from '@langchain/core/messages';
import { KoishiChatMessageHistory } from 'koishi-plugin-chatluna/llm-core/memory/message';
import { ChatLunaChatModel } from 'koishi-plugin-chatluna/llm-core/platform/model';
import { PresetTemplate } from 'koishi-plugin-chatluna/llm-core/prompt';
import { ComputedRef } from '@vue/reactivity';
export interface CompressContextResult {
    inputTokens: number;
    outputTokens: number;
    reducedTokens: number;
    reducedPercent: number;
    compressed: boolean;
    originalMessageCount: number;
    remainingMessageCount: number;
    messages?: BaseMessage[];
}
export interface CompressContextOptions {
    chatHistory: KoishiChatMessageHistory;
    model: ChatLunaChatModel;
    conversationId: string;
    preset?: ComputedRef<PresetTemplate>;
    threshold?: number;
    force?: boolean;
    signal?: AbortSignal;
    instruction?: string;
}
/**
 * Compress chat history when token usage exceeds threshold.
 * Produces structured output: [summary message, ...recent messages].
 */
export declare function compressIfNeeded(opts: CompressContextOptions): Promise<CompressContextResult>;
