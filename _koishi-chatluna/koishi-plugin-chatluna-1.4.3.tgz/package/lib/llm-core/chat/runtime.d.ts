import { Session } from 'koishi';
import { ActiveConversationResolution, ChatInvocationInput, ChatInvocationResult, ConversationRecord, ConversationResolution, Message } from '../../types';
import type { ChatLunaService } from '../../services/chat';
import type { ChatOptions } from '../../services/conversation_runtime';
export declare class ChatRuntime {
    private readonly service;
    constructor(service: ChatLunaService);
    invoke(input: ChatInvocationInput): Promise<ChatInvocationResult>;
    request(session: Session, options: RequestOptions): Promise<{
        resolution: ActiveConversationResolution;
        conversation: ConversationRecord;
        response: Message;
    }>;
    chat(session: Session, conversation: ConversationRecord, message: Message, options?: ChatOptions): Promise<Message>;
    private resolveSession;
    private checkModel;
    private checkPreset;
    private cleanupTransient;
}
interface RequestOptions {
    conversation?: ConversationResolution;
    prepare: (args: {
        conversation: ConversationRecord;
        resolution: ActiveConversationResolution;
    }) => Promise<{
        message: Message;
        chat: ChatOptions;
    }>;
    onResponse?: (args: {
        response: Message;
        conversation: ConversationRecord;
        resolution: ActiveConversationResolution;
    }) => Promise<void>;
}
export {};
