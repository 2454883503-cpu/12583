import { BaseChatMessageHistory } from '@langchain/core/chat_history';
import { Embeddings } from '@langchain/core/embeddings';
import { AIMessage, HumanMessage } from '@langchain/core/messages';
import { ChainValues } from '@langchain/core/utils/types';
import { ComputedRef } from '@vue/reactivity';
import { Context, Session } from 'koishi';
import { PresetTemplate } from 'koishi-plugin-chatluna/llm-core/prompt';
import { ChatLunaLLMCallArg, ChatLunaLLMChainWrapper } from '../chain/base';
import { type CompressContextResult } from './infinite_context';
import type { ArchiveRecord, BindingRecord, ConstraintRecord, ConversationRecord } from '../../types';
import type { ChatLunaService } from '../../services/chat';
export declare class ChatInterface {
    ctx: Context;
    private readonly chatluna;
    private _input;
    private _chatHistory;
    private _chain;
    private _embeddings;
    private _historyMemory?;
    private _chatCount;
    constructor(ctx: Context, input: ChatInterfaceInput, chatluna: ChatLunaService);
    dispose(): void;
    private handleChatError;
    chat(arg: ChatLunaLLMCallArg): Promise<ChainValues>;
    private processChat;
    private handlePostProcessing;
    getChatLunaLLMChainWrapper(): Promise<ChatLunaLLMChainWrapper>;
    createChatLunaLLMChainWrapper(): Promise<void>;
    get chatHistory(): BaseChatMessageHistory;
    get chatMode(): string;
    get embeddings(): ComputedRef<Embeddings>;
    get preset(): ComputedRef<PresetTemplate>;
    clearChatHistory(): Promise<void>;
    compressContext(force?: boolean, instruction?: string): Promise<CompressContextResult>;
    private _createChatHistory;
    private _createHistoryMemory;
}
export interface ChatInterfaceInput {
    chatMode: string;
    autoTitle?: boolean;
    botName?: string;
    preset?: ComputedRef<PresetTemplate>;
    model: string;
    embeddings?: string;
    vectorStoreName?: string;
    conversationId: string;
}
declare module 'koishi' {
    interface Events {
        'chatluna/before-chat': (conversationId: string, message: HumanMessage, promptVariables: ChainValues, chatInterface: ChatInterface, session: Session) => Promise<void>;
        'chatluna/after-chat': (conversationId: string, sourceMessage: HumanMessage, responseMessage: AIMessage, promptVariables: ChainValues, chatInterface: ChatInterface, session: Session) => Promise<void>;
        'chatluna/before-conversation-create': (payload: {
            conversation: ConversationRecord;
            bindingKey: string;
        }) => Promise<void>;
        'chatluna/after-conversation-create': (payload: {
            conversation: ConversationRecord;
            bindingKey: string;
        }) => Promise<void>;
        'chatluna/before-conversation-switch': (payload: {
            bindingKey: string;
            conversation: ConversationRecord;
            previousConversation?: ConversationRecord | null;
        }) => Promise<void>;
        'chatluna/after-conversation-switch': (payload: {
            bindingKey: string;
            conversation: ConversationRecord;
            previousConversation?: ConversationRecord | null;
        }) => Promise<void>;
        'chatluna/after-binding-update': (payload: {
            binding: BindingRecord;
            previousConversationId?: string | null;
        }) => Promise<void>;
        'chatluna/after-constraint-update': (payload: {
            constraint: ConstraintRecord;
        }) => Promise<void>;
        'chatluna/before-conversation-archive': (payload: {
            conversation: ConversationRecord;
        }) => Promise<void>;
        'chatluna/after-conversation-archive': (payload: {
            conversation: ConversationRecord;
            archive: ArchiveRecord;
            path: string;
        }) => Promise<void>;
        'chatluna/before-conversation-restore': (payload: {
            conversation: ConversationRecord;
            archive: ArchiveRecord;
        }) => Promise<void>;
        'chatluna/after-conversation-restore': (payload: {
            conversation: ConversationRecord;
            archive: ArchiveRecord;
        }) => Promise<void>;
        'chatluna/before-conversation-delete': (payload: {
            conversation: ConversationRecord;
        }) => Promise<void>;
        'chatluna/after-conversation-delete': (payload: {
            conversation: ConversationRecord;
        }) => Promise<void>;
        'chatluna/before-conversation-clear-history': (payload: {
            conversation: ConversationRecord;
            chatInterface: ChatInterface;
        }) => Promise<void>;
        'chatluna/clear-chat-history': (conversationId: string, chatInterface: ChatInterface) => Promise<void>;
        'chatluna/after-conversation-clear-history': (payload: {
            conversation: ConversationRecord;
            chatInterface: ChatInterface;
        }) => Promise<void>;
        'chatluna/before-conversation-cache-clear': (payload: {
            conversation: ConversationRecord;
            chatInterface?: ChatInterface;
        }) => Promise<void>;
        'chatluna/after-conversation-cache-clear': (payload: {
            conversation: ConversationRecord;
        }) => Promise<void>;
        'chatluna/conversation-compressed': (payload: {
            conversation: ConversationRecord;
            result: CompressContextResult;
        }) => Promise<void>;
        'chatluna/after-chat-error': (error: Error, conversationId: string, sourceMessage: HumanMessage, promptVariables: ChainValues, chatInterface: ChatInterface, chain?: ChatLunaLLMChainWrapper, requestId?: string) => Promise<void>;
    }
}
