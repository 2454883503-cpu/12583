import { Context, h } from 'koishi';
import { ChatChain } from '../../chains/chain';
import { Config } from '../../config';
export declare function apply(ctx: Context, config: Config, chain: ChatChain): void;
declare module '../../chains/chain' {
    interface ChainMiddlewareName {
        read_chat_message: string;
        transform_chat_message: string;
    }
    interface ChainMiddlewareContextOptions {
        chatMessage?: h[];
    }
}
