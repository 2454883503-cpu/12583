import type { Context, Session } from 'koishi';
import type { Config } from '../../config';
import type { ChatChain } from '../../chains/chain';
import type { Message } from '../../types';
export declare function apply(ctx: Context, config: Config, chain: ChatChain): void;
export declare function censorMessage(ctx: Context, msg: Message, session: Session): Promise<Message>;
declare module '../../chains/chain' {
    interface ChainMiddlewareName {
        censor: never;
    }
}
