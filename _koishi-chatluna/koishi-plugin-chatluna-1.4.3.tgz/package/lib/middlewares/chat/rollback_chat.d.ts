import type { Context } from 'koishi';
import { Config } from '../../config';
import { type ChatChain } from '../../chains/chain';
export declare function apply(ctx: Context, config: Config, chain: ChatChain): void;
declare module '../../chains/chain' {
    interface ChainMiddlewareName {
        rollback_chat: never;
    }
    interface ChainMiddlewareContextOptions {
        rollback_round?: number;
    }
}
