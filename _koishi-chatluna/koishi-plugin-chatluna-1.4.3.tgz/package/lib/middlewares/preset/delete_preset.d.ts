import { Context } from 'koishi';
import { Config } from '../../config';
import { ChatChain } from '../../chains/chain';
export declare function apply(ctx: Context, _config: Config, chain: ChatChain): void;
declare module '../../chains/chain' {
    interface ChainMiddlewareName {
        delete_preset: string;
    }
    interface ChainMiddlewareContextOptions {
        deletePreset?: string;
    }
}
