import { Context } from 'koishi';
import { ChatChain } from '../../chains/chain';
import { Config } from '../../config';
export declare function apply(ctx: Context, config: Config, chain: ChatChain): void;
declare module '../../chains/chain' {
    interface ChainMiddlewareName {
        conversation_new: never;
        conversation_switch: never;
        conversation_list: never;
        conversation_current: never;
        conversation_rename: never;
        conversation_delete: never;
        conversation_use_model: never;
        conversation_use_preset: never;
        conversation_use_mode: never;
        conversation_archive: never;
        conversation_restore: never;
        conversation_export: never;
        conversation_compress: never;
        conversation_rule_model: never;
        conversation_rule_preset: never;
        conversation_rule_mode: never;
        conversation_rule_share: never;
        conversation_rule_lock: never;
        conversation_rule_show: never;
    }
}
