import { Context } from 'koishi';
import { Config } from '../../config';
import { ChatChain } from '../../chains/chain';
export declare function apply(ctx: Context, _config: Config, chain: ChatChain): void;
declare module '../../chains/chain' {
    interface ChainMiddlewareName {
        purge_legacy: never;
        wipe: never;
    }
}
export declare function generateExpression(): {
    expression: string;
    result: number;
};
