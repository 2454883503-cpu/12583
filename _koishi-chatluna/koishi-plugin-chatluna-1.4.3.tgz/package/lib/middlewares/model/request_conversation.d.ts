import { Context } from 'koishi';
import { ChatChain } from 'koishi-plugin-chatluna/chains';
import { Config } from '../../config';
import { Message } from '../../types';
export declare function apply(ctx: Context, config: Config, chain: ChatChain): void;
declare module '../../chains/chain' {
    interface ChainMiddlewareName {
        request_conversation: never;
    }
    interface ChainMiddlewareContextOptions {
        responseMessage?: Message;
        inputMessage?: Message;
        queueCount?: number;
    }
}
