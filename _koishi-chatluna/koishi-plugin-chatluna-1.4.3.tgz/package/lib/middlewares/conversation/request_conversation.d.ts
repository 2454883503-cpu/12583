import type { Context } from 'koishi';
import type { ChatChain } from 'koishi-plugin-chatluna/chains';
import type { Config } from '../../config';
import type { Message } from '../../types';
export declare function apply(ctx: Context, config: Config, chain: ChatChain): void;
declare module '../../chains/chain' {
    interface ChainMiddlewareName {
        request_conversation: never;
    }
    interface ChainMiddlewareContextOptions {
        responseMessage?: Message;
        finalResponseMessage?: Message;
        inputMessage?: Message;
    }
}
